package dataCreation;
 
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.Keys;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

 
public class BenalexIndividualDatacreation {
 
			public static void main (String[] args) throws InterruptedException {
 
				WebDriver driver=new ChromeDriver();
 
				driver.get("https://hxbe-sit.agora.be.hiscox.com/");

				driver.manage().window().maximize();
 
				//lOGIN page

				driver.findElement(By.id("UserName")).sendKeys("pdk");

				driver.findElement(By.id("Password")).sendKeys("1111");

				driver.findElement(By.xpath("//button[@class='login-button idit-btn']")).click();

				//driver.findElement(By.id("login_error")).isDisplayed();

				//driver.findElement(By.xpath("//div[@id='organizationalUnit']//following::select")).click();

				//driver.findElement(By.xpath("//div[@id='organizationalUnit']//following::select/option/option[text()='Hiscox Belgium'])")).click();

				//driver.findElement(By.xpath("//button[@class='login-button idit-btn']")).click();

				driver.findElement(By.id("mainLogoImgDiv")).isDisplayed();

				driver.findElement(By.id("NewMainMenu")).click();
				//Maintain  Contact screen
				driver.findElement(By.xpath("//a[@id='NewContactNewGenFromMenu_Link']")).isDisplayed();
				//Thread.sleep(1000);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@id='NewContactNewGenFromMenu_Link']")).click();
				driver.findElement(By.id("General Details")).isDisplayed();
				driver.findElement(By.id("s2id_IDITForm@entityTypeVO@id")).click();		
				driver.findElement(By.xpath("//div[text()='Individual']")).click();
				driver.findElement(By.id("FirstName")).click();
				driver.findElement(By.id("FirstName")).sendKeys("Gavin");
				driver.findElement(By.id("LastName")).click();
				driver.findElement(By.id("LastName")).sendKeys("Killen");
				driver.findElement(By.xpath("//span[text()='Select']")).click();
				driver.findElement(By.xpath("//div[text()='Mister']")).click();
				driver.findElement(By.xpath("(//span[text()='Select'])[1]")).click();
				driver.findElement(By.xpath("//div[text()='English']")).click();
				driver.findElement(By.xpath("//span[text()='Male']")).isDisplayed();
				driver.findElement(By.xpath("//span[text()='English-BX - NL']")).isDisplayed();
			    driver.findElement(By.xpath("(//span[text()='Select'])[2]")).click();
			    driver.findElement(By.xpath("//input[@id='s2id_autogen7_search']")).sendKeys("Belgium",Keys.TAB);
				driver.findElement(By.xpath("(//input[@class='TextInput align-left required '])[2]")).sendKeys("1234");
				driver.findElement(By.xpath("(//input[@class='TextInput align-left required  validate '])[2]")).sendKeys("Paris");
				driver.findElement(By.xpath("//input[@id='IDITForm@primaryAddressForDisplay@BE@addressVO@streetName']")).sendKeys("Rue Dalayrac");
				driver.findElement(By.xpath("//input[@id='IDITForm@primaryAddressForDisplay@BE@addressVO@houseNr']")).sendKeys("143");

 
				//Telephonenumber
				driver.findElement(By.xpath("//span[@id='select2-chosen-20']")).click();
				driver.findElement(By.xpath("//div[text()='General Telephone']")).click();
				driver.findElement(By.xpath("//input[@id='IDITForm@primaryTelephoneForDisplaytelephoneNumberId']")).sendKeys("2345670003");
 
 
				//Email address
				driver.findElement(By.xpath("//div[contains(text(),'Preferred Dispatch Details')]")).isDisplayed();
				driver.findElement(By.xpath("//span[@id='select2-chosen-23']")).click();
				driver.findElement(By.xpath("//div[text()='Email']")).click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,250)", "");
				driver.findElement(By.xpath("//div[@class='idit-go-buttons']")).click();
				driver.findElement(By.xpath("(//a[text()='Purge'])[1]")).isDisplayed();
				driver.findElement(By.xpath("//a[@title='Add']")).click();
				driver.findElement(By.xpath("//span[text()='General']")).isDisplayed();
				//driver.findElement(By.xpath("//div[text()='E-mail Address']")).isDisplayed();
				driver.findElement(By.xpath("(//input[@type='text'])[4]")).sendKeys("dinesh.kumar@hiscox.com");
				driver.findElement(By.xpath("//button[@title='Select']")).click();
				driver.findElement(By.id("BasicNotificationDialog")).isDisplayed();
				driver.findElement(By.id("DialogOK")).click();
				driver.findElement(By.id("Next")).click();
				driver.findElement(By.id("BasicNotificationDialog")).isDisplayed();
				driver.findElement(By.id("DialogOK")).click();
				driver.findElement(By.xpath("//a[text()='Payment Means']")).isDisplayed();
				driver.findElement(By.xpath("//a[text()='Payment Means']")).click();
				driver.findElement(By.xpath("//div[contains(text(),'Payment Means Details')]")).isDisplayed();
				driver.findElement(By.id("paymentChannelList|New")).click();

//Payment Means Tab	
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("(//span[contains(text(),'Sapiens IDIT')])[4]")).isDisplayed();
				driver.findElement(By.xpath("(//label[contains(text(),'Financial Institute')])[1]")).isDisplayed();
				driver.findElement(By.xpath("(//label[contains(text(),'Country')])[4]")).isDisplayed();
				driver.findElement(By.xpath("(//label[contains(text(),'Country')])[4]//following::div/a/span[text()='Select']")).click();
				driver.findElement(By.xpath("//div[text()='Albania']")).isDisplayed();
				driver.findElement(By.xpath("//div[text()='Belgium']")).click();
				driver.findElement(By.xpath("//label[contains(text(),'IBAN')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@id='bankAccountPopUpVO@bankAccount@ibanField0']")).sendKeys("BE81953329941324");
				//driver.findElement(By.xpath("//input[@class='TextInputLong align-left required ']")).sendKeys("ICICI");
				driver.findElement(By.xpath("(//label[contains(text(),'Bank Account Holder Name')])")).isDisplayed();
				driver.findElement(By.xpath("(//div[contains(text(),'Direct Debit Mandate Details')])")).isDisplayed();
				driver.findElement(By.xpath("//a[@id='bankAccountPopUpVO@directDebitMandate|New']")).click();
				driver.findElement(By.xpath("(//button[contains(text(),'OK')])[3]")).click();
				driver.findElement(By.xpath("//button[@id='Finish']")).click();
 
				//Contact Dashboard 
				driver.findElement(By.xpath("//div[@class='ConfirmationPageMessageDiv']")).isDisplayed();
				//String text=driver.findElement(By.tagName("h2")).getText();
				//System.out.println(text);
				String text1=driver.findElement(By.tagName("b")).getText();
				System.out.println(text1);
				driver.close();
			}}
				 