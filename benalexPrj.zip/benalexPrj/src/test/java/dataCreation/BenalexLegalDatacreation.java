package dataCreation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.Keys;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BenalexLegalDatacreation {

	public static void main (String[] args) throws InterruptedException {



		WebDriver driver=new ChromeDriver();

		driver.get("https://hxbe-sit.agora.be.hiscox.com/");

		driver.manage().window().maximize();

		//lOGIN page

		driver.findElement(By.id("UserName")).sendKeys("pdk");
		driver.findElement(By.id("Password")).sendKeys("1111");
		driver.findElement(By.xpath("//button[@class='login-button idit-btn']")).click();
		driver.findElement(By.id("mainLogoImgDiv")).isDisplayed();
		driver.findElement(By.id("NewMainMenu")).click();
		
		//Maintain  Contact screen
		driver.findElement(By.xpath("//a[@id='NewContactNewGenFromMenu_Link']")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@id='NewContactNewGenFromMenu_Link']")).click();
		driver.findElement(By.id("General Details")).isDisplayed();
		driver.findElement(By.id("s2id_IDITForm@entityTypeVO@id")).click();		
		driver.findElement(By.xpath("//div[text()='Legal entity']")).click();
		driver.findElement(By.id("LastName")).click();
		driver.findElement(By.id("LastName")).sendKeys("Tesla");
		driver.findElement(By.id("s2id_legalFormVO")).click();
		driver.findElement(By.xpath("//div[text()='ASBL']")).isDisplayed();
		driver.findElement(By.xpath("//div[text()='ASBL']")).click();
		driver.findElement(By.xpath("(//span[text()='Select'])[1]")).click();
		driver.findElement(By.xpath("//div[text()='English']")).click();
		driver.findElement(By.xpath("//span[text()='English-BX - NL']")).isDisplayed();

		//Address
		driver.findElement(By.xpath("(//label[text()='Country'][1]//following::a)[2]")).click();
		driver.findElement(By.xpath("//input[@id='s2id_autogen6_search']")).sendKeys("Belgium",Keys.TAB);
		driver.findElement(By.xpath("(//input[@class='TextInput align-left required '])[2]")).sendKeys("1234");
		driver.findElement(By.xpath("(//input[@class='TextInput align-left required  validate '])[2]")).sendKeys("Paris");
		driver.findElement(By.xpath("//input[@id='IDITForm@primaryAddressForDisplay@BE@addressVO@streetName']")).sendKeys("Rue Dalayrac");
		driver.findElement(By.xpath("//input[@id='IDITForm@primaryAddressForDisplay@BE@addressVO@houseNr']")).sendKeys("143");


		//Telephonenumber
		driver.findElement(By.xpath("//div[contains(text(),'Phone Number Details')]")).isDisplayed();
		driver.findElement(By.xpath("//span[text()='General Telephone']")).isDisplayed();
		driver.findElement(By.xpath("//input[@id='IDITForm@primaryTelephoneForDisplaytelephoneNumberId']")).sendKeys("2345670003");


		//Email address
		driver.findElement(By.xpath("//div[contains(text(),'Preferred Dispatch Details')]")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[15]")).click();
		driver.findElement(By.xpath("//div[text()='Email']")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		driver.findElement(By.xpath("//div[@class='idit-go-buttons']")).click();
		driver.findElement(By.xpath("(//a[text()='Purge'])[1]")).isDisplayed();
		driver.findElement(By.xpath("//i[@class='fa fa-plus']")).click();
		driver.findElement(By.xpath("//a[@id='IDITForm@contactEmail|New']")).click();
		driver.findElement(By.xpath("//a[@title='Add']")).click();
		driver.findElement(By.xpath("//div[text()='E-mail Address']")).isDisplayed();
		driver.findElement(By.xpath("//i[@class='fa fa-plus']")).click();
		driver.findElement(By.xpath("//i[@class='fa fa-plus']")).click();
		driver.findElement(By.xpath("//a[@id='IDITForm@contactEmail|New']")).click();
		driver.findElement(By.xpath("//a[@id='IDITForm@contactEmail|New']")).click();
		driver.findElement(By.xpath("//i[@class='fa fa-plus']")).click();
		

		driver.findElement(By.xpath("//span[text()='General']")).isDisplayed();
		driver.findElement(By.xpath("//div[text()='E-mail Address']")).isDisplayed();
		driver.findElement(By.xpath("(//input[@type='text'])[4]")).sendKeys("dinesh.kumar@hiscox.com");
		driver.findElement(By.xpath("//button[@title='Select']")).click();
		driver.findElement(By.id("BasicNotificationDialog")).isDisplayed();
		driver.findElement(By.id("DialogOK")).click();
		driver.findElement(By.id("Next")).click();
		driver.findElement(By.id("BasicNotificationDialog")).isDisplayed();
		driver.findElement(By.id("DialogOK")).click();
		driver.findElement(By.xpath("//a[text()='Payment Means']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Payment Means']")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Payment Means Details')]")).isDisplayed();
		driver.findElement(By.id("paymentChannelList|New")).click();




		//Payment Means Tab	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//span[contains(text(),'Sapiens IDIT')])[4]")).isDisplayed();
		driver.findElement(By.xpath("(//label[contains(text(),'Financial Institute')])[1]")).isDisplayed();
		driver.findElement(By.xpath("(//label[contains(text(),'Country')])[4]")).isDisplayed();
		driver.findElement(By.xpath("(//label[contains(text(),'Country')])[4]//following::div/a/span[text()='Select']")).click();
		driver.findElement(By.xpath("//div[text()='Albania']")).isDisplayed();
		driver.findElement(By.xpath("//div[text()='Belgium']")).click();
		driver.findElement(By.xpath("//label[contains(text(),'IBAN')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@id='bankAccountPopUpVO@bankAccount@ibanField0']")).sendKeys("BE81953329941324");
		//driver.findElement(By.xpath("//input[@class='TextInputLong align-left required ']")).sendKeys("ICICI");
		driver.findElement(By.xpath("(//label[contains(text(),'Bank Account Holder Name')])")).isDisplayed();
		driver.findElement(By.xpath("(//div[contains(text(),'Direct Debit Mandate Details')])")).isDisplayed();
		driver.findElement(By.xpath("//a[@id='bankAccountPopUpVO@directDebitMandate|New']")).click();
		driver.findElement(By.xpath("(//button[contains(text(),'OK')])[3]")).click();
		driver.findElement(By.xpath("//button[@id='Finish']")).click();

		//Contact Dashboard 
		driver.findElement(By.xpath("//div[@class='ConfirmationPageMessageDiv']")).isDisplayed();

		//String text=driver.findElement(By.tagName("h2")).getText();
		//System.out.println(text);
		String text1=driver.findElement(By.tagName("b")).getText();
		System.out.println(text1);
		//driver.close();




		//Policy Creation

		//New proposal creation
		driver.findElement(By.xpath("//button[text()='New proposal']")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Product Name')]/following::span[contains(text(),'Select')][1]")).click();
		driver.findElement(By.xpath("//div[text()='PSC - BE']")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Effective Date')]")).isDisplayed();
		driver.findElement(By.xpath("//label[contains(text(),'Policy End Date')]")).isDisplayed();
		driver.findElement(By.xpath("(//label[contains(text(),'Currency')])[1]")).isDisplayed();
		driver.findElement(By.xpath("//span[text()='Euro']")).isDisplayed();
		driver.findElement(By.xpath("//label[text()='Proposal Valid Until']")).isDisplayed();
		driver.findElement(By.xpath("//label[text()='Brand Company']")).isDisplayed();
		driver.findElement(By.xpath("//input[@value='Hiscox Belgium']")).isDisplayed();
		driver.findElement(By.xpath("//label[text()='General Terms and Conditions Version']")).isDisplayed();



		//Intermediary
		driver.findElement(By.xpath("//div[contains(text(),'Intermediary')]")).isDisplayed();
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,350)", "");
		driver.findElement(By.xpath("//div[contains(text(),'Sales Transaction Channel')]")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[3]")).click();
		driver.findElement(By.id("s2id_autogen9_search")).sendKeys("FADBI", Keys.TAB);
		driver.findElement(By.xpath("//div[text()='Account']")).isDisplayed();
		Thread.sleep(500);
		driver.findElement(By.xpath("(//span[text()='Select'])[3]")).click();

		driver.findElement(By.xpath("//input[@id='s2id_autogen9_search']")).sendKeys("MG Broker street 12",Keys.TAB);
		//driver.findElement(By.xpath("//div[text()='MG Broker street 12 1234 city Belgium]")).isDisplayed();
		driver.findElement(By.xpath("//div[text()='Account']")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[3]")).click();
		driver.findElement(By.xpath("//div[text()='Intermediary MG Broker HB81212178 DB EUR (Hiscox Belgium)']")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Sales Transaction Channel')]")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[4]")).click();
		driver.findElement(By.xpath("//div[text()='Intermediary']")).click();
		driver.findElement(By.xpath("//label[text()='Method of Placement']")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[4]")).click();
		driver.findElement(By.xpath("//div[text()='Pre Defined - Manual Input']")).click();
		driver.findElement(By.id("Next")).click();


		//Policy Details
		//Classification
		driver.findElement(By.xpath("//div[contains(text(),'Classification')]")).isDisplayed();
		driver.findElement(By.xpath("//div[text()='Risk Description']")).isDisplayed();
		driver.findElement(By.xpath("(//a[@title='Add'])[1]")).click();
		//driver.findElement(By.xpath("//div[contains(text(),'Policy Contacts')]")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[1]")).click();
		driver.findElement(By.xpath("//div[text()='Aerospace']")).click();
		driver.findElement(By.xpath("(//input[@title='Aerospace'])[1]")).isDisplayed();
		driver.findElement(By.xpath("(//label[text()='Revenue Type'])[1]")).isDisplayed();
		driver.findElement(By.xpath("//span[text()='Turnover']")).isDisplayed();
		driver.findElement(By.xpath("//label[text()='Revenue Excluding USA/Canada (€)']")).isDisplayed();
		driver.findElement(By.id("pscRevenueExclUSACanadaEU")).sendKeys("2500");												
		driver.findElement(By.id("Next")).click();
		driver.findElement(By.xpath("//a[text()='Maintain LOB Details']")).isDisplayed();
		////// reaming////
		//Lob Covers
		driver.findElement(By.xpath("//div[contains(text(),'Lob Covers')]")).isDisplayed();
		driver.findElement(By.xpath("//label[@id='flattendListflattenedCoverItems|3@isSelectedLabel']")).click();
		driver.findElement(By.xpath("//button[text()='Cancel']")).isDisplayed();
		driver.findElement(By.xpath("//button[text()='Next']")).click();

		driver.findElement(By.xpath("//div[contains(text(),'Payments')]")).isDisplayed();

		driver.findElement(By.xpath("//span[text()='Direct Billing']")).isDisplayed();

		//Quote creation
		//driver.findElement(By.xpath("//div[text()='To be reviewed - IA']")).click();

		//Policy creation
		driver.findElement(By.xpath("//label[contains(text(),'Decision')]//following::div/a/span[text()='Save Proposal']")).click();
		driver.findElement(By.xpath("//div[text()='Confirm Policy']")).click();
		driver.findElement(By.xpath("(//label[text()='Reason'])[1]")).isDisplayed();
		driver.findElement(By.xpath("(//span[text()='Select'])[2]")).click();

		driver.findElement(By.xpath("//div[text()='Final']")).click();

		driver.findElement(By.xpath("//button[@id='Next']")).click();
		driver.findElement(By.xpath("//span[text()='Select']")).click();
		driver.findElement(By.xpath("//div[@id='select2-result-label-3']")).click();
		driver.findElement(By.xpath("//button[text()='Finish']")).click();
		driver.findElement(By.xpath("//button[text()='Finish']")).click();
		//Object webdriver;
		//String text = driver.findElement(webdriver.By.xpath("//div/span")).getText();
		driver.findElement(By.xpath("//div[@class='ConfirmationPageMessageDiv']")).isDisplayed();
		//Get the text
		String text2=driver.findElement(By.tagName("b")).getText();
		System.out.println(text2);
		driver.findElement(By.xpath("//button[@id='Ok']")).isDisplayed();
		driver.close();


	}}

//Maintain LoB details

